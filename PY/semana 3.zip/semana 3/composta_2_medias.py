#estrutura composta
media = 6.9
if (media >= 7.0):
    print("aluno aprovado")
elif (media < 4):
    print ("Aluno Reprovado")
else:
    print("Aluno em recuperação")