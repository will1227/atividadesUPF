n = int(input("Informe o numero "))
#testando se é par.
if (n % 2 == 0):
    print(" o numero par ")
else :
    print("o numero impar")