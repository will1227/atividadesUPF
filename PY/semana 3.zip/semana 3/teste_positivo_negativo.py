n = float(input("informe um numero: "))
if (n >= 0):
    print("numero positivo")
else : print ("numero Negativo")