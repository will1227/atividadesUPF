n1 = int(input("informe o primeiro numero "))
n2 = int(input("informe o segundo numero "))
if (n1 > n2):
    print("o primeiro numero é maior que o segundo")
elif (n1 < n2):
    print("o segundo numero é maior que o primeiro")
else: print("os numeros são iguais")