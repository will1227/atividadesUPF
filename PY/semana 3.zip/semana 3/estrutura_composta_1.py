#estrutura composta
media = 9.5
if (media >= 7.0):
    print("aluno aprovado")
else: print ("aluno reprovado")