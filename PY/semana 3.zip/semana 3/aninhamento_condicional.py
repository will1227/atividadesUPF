#estrutura composta
media = 10
if (media >= 7.0):
    print("aluno aprovado")
    if(media == 10):
        print("parabens, você tirou nota maxima")
elif (media < 4):
    print ("Aluno Reprovado")
else:
    print("Aluno em recuperação")
