#estrutura condicional simples
media = 7.5
if (media >= 7.0):
    print("aluno aprovado")

    