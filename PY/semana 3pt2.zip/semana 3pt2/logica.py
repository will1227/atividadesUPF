n1 = float(input("digite o numero "))
n2 = float(input("digite o numero "))



soma = (n1 + n2)

soma /= 2

print (soma)