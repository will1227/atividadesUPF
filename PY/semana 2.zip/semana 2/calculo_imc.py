peso = float(input("insira seu peso "))
altura = float(input("insira sua altura "))

imc = (peso / (altura * altura))


print ("seu IMC é %s" % imc)