altura = float(input("selecione a altura "))
largura = float(input("selecione a largura "))


area = (altura * largura)


print ("a area de um triangulo ", + altura, + largura, "é", + area, "m2" )